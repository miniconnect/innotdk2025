package hu.webarticum.inno.paperdatabase.abstractgenerator.model.keyword;

import hu.webarticum.inno.paperdatabase.abstractgenerator.model.PlaceholderType;

public class RegexWordGenerator implements WordGenerator {
    
    public RegexWordGenerator(String regex, long seed) {
        // TODO
    }

    @Override
    public String generate(PlaceholderType placeholderType) {
        // TODO
        return "hello";
    }

}
